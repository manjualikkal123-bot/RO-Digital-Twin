import json

with open('data/processed/nia_nandesari.json', 'r') as f:
    data = json.load(f)

print(f"Total JSON records: {len(data)}")

# Check timestamp format
print("Sample timestamps:")
for r in data[:3]:
    ts = r.get("timestamp", "MISSING")
    print(f"  {ts}")

# Check the last record
print("Last timestamp:", data[-1].get("timestamp", "MISSING"))

# Check completeness of each HPA
for hpa_name in ['HPA1', 'HPA2', 'HPA3', 'HPA4', 'HPA5']:
    with_data = sum(1 for r in data if r.get(hpa_name) and len(r[hpa_name]) > 5)
    sparse = sum(1 for r in data if r.get(hpa_name) and len(r[hpa_name]) <= 5)
    missing = sum(1 for r in data if not r.get(hpa_name))
    print(f"\n{hpa_name}: full={with_data}, sparse={sparse}, missing={missing}")

    # Show a sparse record
    for r in data:
        hpa = r.get(hpa_name, {})
        if hpa and len(hpa) <= 5:
            print(f"  Sample sparse record at {r.get('timestamp')}: {hpa}")
            break

# Check ARR1_IL values across all HPA trains
print("\n--- ARR1_IL stats (first 5 HPA1 records) ---")
for r in data[:5]:
    hpa1 = r.get('HPA1', {})
    print(f"  {r.get('timestamp')}: ARR1_IL={hpa1.get('ARR1_IL')}, PERM_FLOW_12={hpa1.get('PERM_FLOW_12')}, PERM_CDT_12={hpa1.get('PERM_CDT_12')}")
