﻿"""
convert_nia.py  —  Excel -> data/processed/nia_nandesari.json
─────────────────────────────────────────────────────────────
Reads the NIA Nandesari logsheet Excel workbook and produces the
nested HPA1-HPA5 JSON that GlobalSyncManager.fetchNandesariData()
and mapNandesariRowToTelemetry() expect.

Excel structure (verified against June 2026 file):
  - Each sheet = one calendar day, named "DD.MM.YYYY"
  - Each sheet contains 5 stacked HPA blocks, each shaped as:
      row N   : "DATE"  label in col 0
      row N+1 : "   HPA n  " label (padded string)
      row N+2 : group headers
      row N+3 : sub-headers
      row N+4 to N+15 : 12 hourly readings, TIME in col 0 as datetime.time
      row N+16: averages row  (SKIP - contains broken formulas)
      row N+17: blank separator
  - Backwash rows have TIME in col 0 but data cols are NaN/0 or
    contain strings like "BACK", "WASH", "P.T.F." - skip these.

Output JSON schema (one entry per timestamp):
  {
    "timestamp": "2026-06-01T00:30:00Z",
    "HPA1": { <tag>: <float>, ... },
    "HPA2": { ... },
    "HPA3": { ... },
    "HPA4": { ... },
    "HPA5": { ... }
  }

Column map (1-based index within each 30-col block):
  col  2 -> TMF_IN          col  3 -> TMF_OUT         col  4 -> TMF_DP
  col  5 -> TURB_FEED       col  6 -> TURB_TMF         col  7 -> TURB_ACF
  col  9 -> FEED_PH         col 10 -> VFD_RPM
  col 11 -> ARR1_IL         col 12 -> ARR1_OL          col 13 -> ARR1_DP
  col 14 -> ARR2_IL         col 15 -> ARR2_OL          col 16 -> ARR2_DP
  col 17 -> PERM_FLOW_12    col 18 -> PERM_FLOW_2
  col 19 -> PERM_TDS_12     col 20 -> PERM_CDT_12
  col 21 -> STAGE3_IL       col 22 -> STAGE3_OL        col 23 -> STAGE3_DP
  col 24 -> PERM_FLOW_3     col 25 -> PERM_TDS_3       col 26 -> PERM_CDT_3
  col 27 -> REJECT_FLOW     col 28 -> DG_TDS           col 29 -> PERM_PH
"""

import re
import json
import math
import datetime
import pandas as pd

COLUMN_MAP = {
     2: 'TMF_IN',      3: 'TMF_OUT',    4: 'TMF_DP',
     5: 'TURB_FEED',   6: 'TURB_TMF',   7: 'TURB_ACF',
     9: 'FEED_PH',    10: 'VFD_RPM',
    11: 'ARR1_IL',    12: 'ARR1_OL',   13: 'ARR1_DP',
    14: 'ARR2_IL',    15: 'ARR2_OL',   16: 'ARR2_DP',
    17: 'PERM_FLOW_12', 18: 'PERM_FLOW_2',
    19: 'PERM_TDS_12', 20: 'PERM_CDT_12',
    21: 'STAGE3_IL',  22: 'STAGE3_OL', 23: 'STAGE3_DP',
    24: 'PERM_FLOW_3', 25: 'PERM_TDS_3', 26: 'PERM_CDT_3',
    27: 'REJECT_FLOW', 28: 'DG_TDS',   29: 'PERM_PH',
}

DP_PAIRS = [
    ('TMF_IN',    'TMF_OUT',    'TMF_DP'),
    ('ARR1_IL',   'ARR1_OL',   'ARR1_DP'),
    ('ARR2_IL',   'ARR2_OL',   'ARR2_DP'),
    ('STAGE3_IL', 'STAGE3_OL', 'STAGE3_DP'),
]


def safe_float(v):
    try:
        f = float(v)
        return None if math.isnan(f) else f
    except (TypeError, ValueError):
        return None


def time_to_hhmm(v):
    if isinstance(v, datetime.time):
        return f"{v.hour:02d}:{v.minute:02d}"
    if isinstance(v, float) and 0.0 <= v < 1.0:
        total_min = round(v * 1440)
        return f"{total_min // 60:02d}:{total_min % 60:02d}"
    if isinstance(v, str):
        m = re.match(r'^(\d{1,2}):(\d{2})', v.strip())
        if m:
            return f"{int(m.group(1)):02d}:{int(m.group(2)):02d}"
    return None


def sheet_name_to_iso(name):
    m = re.match(r'^(\d{1,2})\.(\d{1,2})\.(\d{4})$', name.strip())
    if not m:
        return None
    return f"{m.group(3)}-{m.group(2).zfill(2)}-{m.group(1).zfill(2)}"


def parse_sheet(matrix, iso_date, timeline):
    for r in range(len(matrix)):
        row = matrix[r]
        col0 = str(row[0] if len(row) > 0 else '').strip().upper()
        if col0 != 'DATE':
            continue

        label_row = matrix[r + 1] if r + 1 < len(matrix) else []
        hpa_label = next(
            (c for c in label_row if isinstance(c, str) and re.search(r'HPA\s*\d', c, re.I)),
            None
        )
        if not hpa_label:
            continue
        hpa_match = re.search(r'HPA\s*(\d)', hpa_label, re.I)
        if not hpa_match:
            continue
        hpa_key = f"HPA{hpa_match.group(1)}"

        for dr in range(r + 4, min(r + 16, len(matrix))):
            data_row = matrix[dr]
            if not data_row:
                continue
            time_val = data_row[0] if len(data_row) > 0 else None
            hhmm = time_to_hhmm(time_val)
            if hhmm is None:
                continue
            # Skip backwash rows: non-empty strings in data columns
            if any(
                isinstance(data_row[c] if c < len(data_row) else None, str)
                and str(data_row[c]).strip() not in ('', 'nan')
                for c in range(1, min(10, len(data_row)))
            ):
                continue

            ts_key = f"{iso_date}T{hhmm}:00Z"
            if ts_key not in timeline:
                timeline[ts_key] = {"timestamp": ts_key}

            hpa_block = timeline[ts_key].setdefault(hpa_key, {})
            for col_1, tag in COLUMN_MAP.items():
                raw = data_row[col_1 - 1] if col_1 - 1 < len(data_row) else None
                val = safe_float(raw)
                if val is not None:
                    hpa_block[tag] = val

        # Fix zero DP readings by computing from I/L - O/L
        for ts_key, rec in timeline.items():
            block = rec.get(hpa_key, {})
            for in_t, out_t, dp_t in DP_PAIRS:
                if block.get(dp_t) == 0 and in_t in block and out_t in block:
                    block[dp_t] = round(block[in_t] - block[out_t], 6)


def main():
    excel_path = 'data/NIA  log sheet 01 TO 30 JUN 2026.xlsx'
    output_path = 'data/processed/nia_nandesari.json'

    print(f"Reading: {excel_path}")
    wb = pd.read_excel(excel_path, sheet_name=None, header=None)

    timeline = {}
    skipped = []
    for sheet_name, df in wb.items():
        iso_date = sheet_name_to_iso(sheet_name)
        if iso_date is None:
            skipped.append(sheet_name)
            continue
        parse_sheet(df.values.tolist(), iso_date, timeline)

    if skipped:
        print(f"Skipped non-date sheets: {skipped}")

    records = [v for _, v in sorted(timeline.items())]

    # Keep only timestamps with at least one HPA block that has real data (>1 field)
    valid = [
        r for r in records
        if any(r.get(f'HPA{i}') and len(r[f'HPA{i}']) > 1 for i in range(1, 6))
    ]
    dropped = len(records) - len(valid)
    if dropped:
        print(f"Dropped {dropped} timestamps with no usable HPA data")

    with open(output_path, 'w') as f:
        json.dump(valid, f, indent=2)

    print(f"\nWrote: {output_path}")
    print(f"  Total timestamps : {len(valid)}")
    for i in range(1, 6):
        hk = f'HPA{i}'
        full   = sum(1 for r in valid if r.get(hk) and len(r[hk]) > 5)
        sparse = sum(1 for r in valid if r.get(hk) and 1 < len(r[hk]) <= 5)
        missing= sum(1 for r in valid if not r.get(hk))
        print(f"  {hk}: full={full}, sparse/backwash={sparse}, missing={missing}")


if __name__ == '__main__':
    main()
