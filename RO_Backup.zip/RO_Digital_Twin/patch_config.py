import json

path = r'frontend\src\config\plant_macro_config.json'
with open(path, 'r', encoding='utf-8') as f:
    data = json.load(f)

# Step 1: Rename RO-2 dosing tanks
for key in ['701', '801', '901']:
    base = key[0] # '7', '8', '9'
    for eq in data['ro2Blueprints'][key]['equipment']:
        if eq['id'] == f'T-{base}01':
            eq['id'] = f'DOS-{key}A'
            eq['label'] = 'Dosing Tank A (verify vs P&ID)'
        elif eq['id'] == f'T-{base}02':
            eq['id'] = f'DOS-{key}B'
            eq['label'] = 'Dosing Tank B (verify vs P&ID)'
        elif eq['id'] == f'T-{base}03':
            eq['id'] = f'T-{key}'
            eq['label'] = 'Antiscalant Dosing'

# Step 2: Add 4 shared CIP tanks
cip_tanks = [
  { "id": "T-101", "type": "VerticalVessel", "pos": [-15, 0, -12], "dims": { "r": 1.5, "h": 4 }, "label": "UF CIP TANK", "color": "#d97706" },
  { "id": "T-404", "type": "VerticalVessel", "pos": [45, 0, -12], "dims": { "r": 1.5, "h": 4 }, "label": "RO-1 CIP TANK", "color": "#d97706" },
  { "id": "T-702", "type": "VerticalVessel", "pos": [115, 0, -12], "dims": { "r": 1.5, "h": 4 }, "label": "RO-2 CIP TANK", "color": "#d97706" },
  { "id": "T-1001", "type": "VerticalVessel", "pos": [185, 0, -12], "dims": { "r": 1.5, "h": 4 }, "label": "RO-P CIP TANK", "color": "#d97706" }
]
data['shared']['equipment'].extend(cip_tanks)

# Step 3: Add dedicated CIP pumps
data['ro1Blueprints']['401']['equipment'].append({
    "id": "P-405", "type": "PumpAssembly", "pos": [48, 0, -8], "state": "Stopped", "rpm": 0, "color": "red", "label": "RO-1 CIP Pump"
})
data['ro2Blueprints']['701']['equipment'].append({
    "id": "P-704", "type": "PumpAssembly", "pos": [118, 0, -8], "state": "Stopped", "rpm": 0, "color": "red", "label": "RO-2 CIP Pump"
})

with open(path, 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2)

print("Patch applied successfully.")
