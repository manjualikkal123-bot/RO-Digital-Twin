const http = require('http');

const req = http.request('http://localhost:3000/api/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' }
}, (res) => {
  let body='';
  res.on('data', d => body += d);
  res.on('end', () => {
    const token = JSON.parse(body).token;
    if(!token) return console.log('Login failed', body);
    
    console.log('Login success. Token:', token);
    
    http.get('http://localhost:3000/api/me', { headers: { 'Authorization': 'Bearer ' + token } }, (res2) => {
      let body2='';
      res2.on('data', d => body2 += d);
      res2.on('end', () => {
         console.log('/api/me =>', res2.statusCode, body2);
         
         http.get('http://localhost:3000/api/fleet', { headers: { 'Authorization': 'Bearer ' + token } }, (res3) => {
            let body3='';
            res3.on('data', d => body3 += d);
            res3.on('end', () => {
               console.log('/api/fleet =>', res3.statusCode, body3);
            });
         });
      });
    });
  });
});
req.write(JSON.stringify({ username: 'testadmin', password: 'testpassword' }));
req.end();
