const fs = require('fs');

const createUFBlueprint = () => ({
  equipment: [
    { id: 'P-101', type: 'PumpAssembly', pos: [-25, 0, 2], state: 'Running', rpm: 2850, label: 'Feed Pump' },
    { id: 'ASF-101', type: 'VerticalVessel', pos: [-18, 0, 2], dims: { r: 0.8, h: 3 }, label: 'Auto Strainer' },
    { id: 'MCF-101A', type: 'VerticalVessel', pos: [-12, 0, 4], dims: { r: 0.6, h: 2.5 }, label: 'MCF Stack A' },
    { id: 'MCF-101B', type: 'VerticalVessel', pos: [-12, 0, 0], dims: { r: 0.6, h: 2.5 }, label: 'MCF Stack B' },
    { id: 'P-102', type: 'PumpAssembly', pos: [-7, 0, 2], state: 'Running', rpm: 2900, label: 'System Pump' },
    { id: 'AB-101', type: 'PumpAssembly', pos: [0, 0, 10], state: 'Stopped', rpm: 0, label: 'Air Blower' },
    { id: 'UF-RACK-101', type: 'UFRack', pos: [4, 0, 0], count: 14, spacing: 1.15, label: 'UF Membrane Rack' }
  ],
  valves: [],
  instruments: [],
  pipes: [
    { id: 'suction', color: 'WHITE', points: [[-29, 0.6, 2], [-25, 0.6, 2]] },
    { id: 'p101-to-asf', color: 'WHITE', points: [[-25, 1.6, 2], [-18, 1.6, 2]] },
    { id: 'asf-to-mcf', color: 'WHITE', points: [[-18, 1.6, 2], [-14, 1.6, 2], [-14, 1.6, 4], [-12, 1.6, 4]] },
    { id: 'asf-to-mcf-b', color: 'WHITE', points: [[-14, 1.6, 2], [-14, 1.6, 0], [-12, 1.6, 0]] },
    { id: 'mcf-to-p102', color: 'WHITE', points: [[-10, 1.6, 4], [-10, 1.6, 2], [-7, 1.6, 2]] },
    { id: 'mcf-b-to-p102', color: 'WHITE', points: [[-10, 1.6, 0], [-10, 1.6, 2]] },
    { id: 'p102-to-rack', color: 'WHITE', points: [[-7, 1.6, 2], [4, 1.6, 2], [4, 1.6, 0]] },
    { id: 'permeate-out', color: 'BLUE', points: [[4, 9.6, 0], [16, 9.6, 0]] }
  ]
});

const createROBlueprint = (series, isCIP, ox) => {
  const c = isCIP ? 'red' : 'green';
  return {
    equipment: [
      { id: `P-${series}01`, type: 'PumpAssembly', pos: [ox-20, 0, 4], state: isCIP ? 'Stopped' : 'Running', color: isCIP ? 'red' : 'green', label: 'RO Feed Pump' },
      { id: `MCF-${series}01`, type: 'VerticalVessel', pos: [ox-13, 0, 4], dims: { r: 1.2, h: 3 }, label: 'Polishing MCF' },
      { id: `T-${series}01`, type: 'VerticalVessel', pos: [ox-17, 0, 8], dims: { r: 0.6, h: 2.5 }, label: 'De-Chlorination' },
      { id: `T-${series}02`, type: 'VerticalVessel', pos: [ox-15, 0, 8], dims: { r: 0.6, h: 2.5 }, label: 'Acid Dosing' },
      { id: `T-${series}03`, type: 'VerticalVessel', pos: [ox-13, 0, 8], dims: { r: 0.6, h: 2.5 }, label: 'Antiscalant' },
      { id: `P-${series}02`, type: 'PumpAssembly', pos: [ox-8, 0, 4], state: isCIP ? 'Stopped' : 'Running', rpm: isCIP ? 0 : 2412, color: isCIP ? 'red' : 'green', label: 'RO HP Pump' },
      { id: `RO-ARRAY-${series}01`, type: 'RORack', pos: [ox, 0, 0], stages: [6, 4, 2], label: `RO-${series}01 CORE` },
      { id: `P-${series}03`, type: 'PumpAssembly', pos: [ox+3, 0, -4], state: 'Running', rpm: isCIP ? 107 : 2375, color: 'green', label: 'Inter-Boost 1' },
      { id: `P-${series}04`, type: 'PumpAssembly', pos: [ox+8, 0, -4], state: 'Running', rpm: isCIP ? 99 : 2104, color: 'green', label: 'Inter-Boost 2' },
    ],
    valves: [],
    instruments: [],
    pipes: [
      { id: 'ro-feed-line', color: 'SKYBLUE', points: [[ox-25, 0.4, 4], [ox-25, 0.4, 7], [ox-20, 0.4, 7], [ox-20, 0.4, 4]] },
      { id: 'ro-pre-treatment', color: 'WHITE', points: [[ox-20, 1.6, 4], [ox-13, 1.6, 4]] },
      { id: 'dosing-tap-1', color: 'WHITE', points: [[ox-17, 1, 8], [ox-17, 1, 4]] },
      { id: 'dosing-tap-2', color: 'WHITE', points: [[ox-15, 1, 8], [ox-15, 1, 4]] },
      { id: 'dosing-tap-3', color: 'WHITE', points: [[ox-13, 1, 8], [ox-13, 1, 4]] },
      { id: 'ro-mcf-to-hp', color: 'WHITE', points: [[ox-13, 4.6, 4], [ox-8, 4.6, 4], [ox-8, 1.6, 4]] },
      { id: 'hp-to-ro', color: 'WHITE', points: [[ox-8, 1.6, 4], [ox-3, 1.6, 4], [ox-3, 1.6, 0], [ox, 1.6, 0]] },
      { id: 'ro-product', color: 'CYAN', points: [[ox, 8, 0], [ox+15, 8, 0]] },
      { id: 'ro-reject', color: 'RED', points: [[ox+10, 0.4, 0], [ox+15, 0.4, 0]] }
    ]
  };
};

const createPolishingBlueprint = (series, ox) => {
  return {
    equipment: [
      { id: `P-${series}`, type: 'PumpAssembly', pos: [ox-20, 0, 4], state: 'Running', color: 'green', label: 'RO-P Feed Pump' },
      { id: `DP-${series}`, type: 'VerticalVessel', pos: [ox-16, 0, 8], dims: { r: 0.6, h: 2.5 }, label: 'Antiscalant Dosing' },
      { id: `MCF-${series}`, type: 'VerticalVessel', pos: [ox-12, 0, 4], dims: { r: 1.2, h: 3 }, label: 'Polishing MCF' },
      { id: `P-${series+1}`, type: 'PumpAssembly', pos: [ox-6, 0, 4], state: 'Running', rpm: 2500, color: 'green', label: 'RO-P System Pump' },
      { id: `RO-ARRAY-${series}`, type: 'RORack', pos: [ox+2, 0, 0], stages: [4, 4], label: `ROP-${series} CORE` },
    ],
    valves: [],
    instruments: [],
    pipes: [
      { id: 'rop-feed-line', color: 'SKYBLUE', points: [[ox-25, 0.4, 4], [ox-25, 0.4, 7], [ox-20, 0.4, 7], [ox-20, 0.4, 4]] },
      { id: 'rop-pre-treatment', color: 'WHITE', points: [[ox-20, 1.6, 4], [ox-12, 1.6, 4]] },
      { id: 'rop-dosing-tap', color: 'WHITE', points: [[ox-16, 1, 8], [ox-16, 1, 4]] },
      { id: 'rop-mcf-to-hp', color: 'WHITE', points: [[ox-12, 4.6, 4], [ox-6, 4.6, 4], [ox-6, 1.6, 4]] },
      { id: 'rop-hp-to-ro', color: 'WHITE', points: [[ox-6, 1.6, 4], [ox-1, 1.6, 4], [ox-1, 1.6, 0], [ox+2, 1.6, 0]] },
      { id: 'rop-product', color: 'CYAN', points: [[ox+2, 8, 0], [ox+12, 8, 0]] },
      { id: 'rop-reject', color: 'RED', points: [[ox+10, 0.4, 0], [ox+15, 0.4, 0]] }
    ]
  };
};

const macroConfig = {
  system: 'ZLD-MACRO-PLANT',
  timer: { elapsed: 142, remaining: 38 },
  shared: {
    equipment: [
      { id: 'FWST-101', type: 'RectangularTank', pos: [-40, 0, 4], dims: { w: 8, h: 12, d: 8 }, label: 'UF Feed Water Tank' },
      { id: 'ROFWST-401', type: 'RectangularTank', pos: [35, 0, 4], dims: { w: 6, h: 10, d: 6 }, label: 'RO-1 Feed Water Tank' },
      
      { id: 'LAMELLA-2', type: 'RectangularTank', pos: [100, 0, -20], dims: { w: 8, h: 6, d: 12 }, label: 'LAMELLA CLARIFIER-2' },
      { id: 'ROFWST-701', type: 'RectangularTank', pos: [110, 0, 4], dims: { w: 6, h: 10, d: 6 }, label: 'RO-2 Feed Water Tank' },

      { id: 'ROPFWST-1001', type: 'RectangularTank', pos: [180, 0, 4], dims: { w: 8, h: 12, d: 8 }, label: 'RO-P Feed Water Tank' },
      
      { id: 'EVAPORATOR', type: 'VerticalVessel', pos: [180, 0, -35], dims: { r: 4, h: 12 }, label: 'EVAPORATOR BLOCK' },
      { id: 'LT-1201', type: 'RectangularTank', pos: [260, 0, -10], dims: { w: 10, h: 15, d: 10 }, label: 'RO-P PERMEATE WATER STORAGE TANK' }
    ],
    valves: [],
    instruments: []
  },
  trainBlueprint: createUFBlueprint(),
  
  ro1Blueprints: {
    '401': createROBlueprint(4, false, 70),
    '501': createROBlueprint(5, true, 70),
    '601': createROBlueprint(6, false, 70)
  },

  ro2Blueprints: {
    '701': createROBlueprint(7, false, 140),
    '801': createROBlueprint(8, false, 140),
    '901': createROBlueprint(9, false, 140)
  },
  
  ropBlueprints: {
    '1001': createPolishingBlueprint(1001, 215),
    '1101': createPolishingBlueprint(1101, 215),
    '1201': createPolishingBlueprint(1201, 215)
  }
};

fs.writeFileSync('C:/Users/hp/OneDrive/Desktop/RO_Digital_Twin/frontend/src/config/plant_macro_config.json', JSON.stringify(macroConfig, null, 2));
console.log('Successfully regenerated plant_macro_config.json with full 12-skid ZLD layout.');
