const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const db = new sqlite3.Database('./users.db');
const hash = bcrypt.hashSync('testpassword', 10);
db.run(`INSERT INTO users (username, password_hash, role, company_name, allowed_plant_ids, pcb_limits, contact_name, contact_email, contact_phone) VALUES (?, ?, 'admin', 'Permionics', '["jetl_hyderabad","waaree_chikhli","nia_nandesari"]', null, 'Test Admin', 'test@example.com', '123')`, ['testadmin', hash], function(err) {
  if (err) console.error(err);
  else console.log('Inserted testadmin');
});
