import re

with open("c:/Users/hp/OneDrive/Desktop/RO_Digital_Twin/frontend/src/pages/AdvancedAnalytics.jsx", "r", encoding="utf-8") as f:
    content = f.read()

# 1. Extract Chart 3
chart3_start = content.find("{/* Chart 3: Thermodynamic Correlation */}")
chart4_start = content.find("{/* Chart 4: Fouling Zone Detection */}")
chart3_block = content[chart3_start:chart4_start]

# 2. Extract Chart 4
cta_start = content.find("{/* ── 5. SIMULATOR CTA")
chart4_block = content[chart4_start:cta_start]

# 3. Extract Simulator CTA
bottom_end = content.find("        </div>\n      </div>\n    </div>\n  );\n}")
cta_block = content[cta_start:bottom_end]

# 4. Remove BOTTOM SECTION from original string
bottom_section_start = content.find("{/* ── BOTTOM SECTION: MULTIVARIATE + CTA ─────────────────── */}")
content_no_bottom = content[:bottom_section_start] + "    </div>\n  );\n}\n"

# 5. Insert Chart 3 and Chart 4 into lg:grid-cols-2
grid_end = content_no_bottom.find("            </div>\n          </div>\n\n        </div>\n\n        {/* ── SIDEBAR RCA ENGINE ───────────────────────────────────── */}")
if grid_end == -1:
    print("Could not find grid end")
    exit(1)

insert_pos = content_no_bottom.rfind("          </div>\n\n        </div>\n\n        {/* ── SIDEBAR RCA ENGINE", 0, grid_end + 100)
# Wait, let's just find the end of Chart 2
chart2_str = "{/* Chart 2: Degradation Forecast */}"
chart2_start = content_no_bottom.find(chart2_str)
chart2_end = content_no_bottom.find("            </div>\n          </div>", chart2_start) + 19 # "            </div>\n"

# The grid-cols-2 ends with "          </div>\n\n        </div>\n"
insertion_point = content_no_bottom.find("          </div>", chart2_end)

new_grid_content = content_no_bottom[:insertion_point] + "\n" + chart3_block + chart4_block + content_no_bottom[insertion_point:]

# 6. Insert Simulator CTA under RCA Engine
rca_engine_end = new_grid_content.find("Run Deep RCA Diagnostic <ChevronRight size={14}/>\n              </button>\n            </div>\n          </div>\n")
if rca_engine_end == -1:
    print("Could not find RCA engine end")
    exit(1)

rca_engine_end_pos = rca_engine_end + len("Run Deep RCA Diagnostic <ChevronRight size={14}/>\n              </button>\n            </div>\n          </div>\n")

# To fix indentation for cta_block (it's currently indented with 10 spaces, needs 10 spaces)
# It's already mostly indented with 10 spaces.
final_content = new_grid_content[:rca_engine_end_pos] + "\n          {/* ── 5. SIMULATOR CTA ─────────────────────────────────── */}\n" + cta_block[cta_block.find('<div className="bg-gradient'):] + new_grid_content[rca_engine_end_pos:]

with open("c:/Users/hp/OneDrive/Desktop/RO_Digital_Twin/frontend/src/pages/AdvancedAnalytics.jsx", "w", encoding="utf-8") as f:
    f.write(final_content)

print("Done")
