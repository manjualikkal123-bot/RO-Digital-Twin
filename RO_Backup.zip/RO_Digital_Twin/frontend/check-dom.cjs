const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({ headless: 'new' });
  const page = await browser.newPage();
  
  // Set the token so we don't have to login
  await page.evaluateOnNewDocument(() => {
    localStorage.setItem('dt_token', 'dummy_token'); // Backend is bypassed? Wait, if backend is bypassed, the token might be rejected by /api/me.
    // Let's just go to login page and login if needed, but it might be easier to just bypass.
  });

  try {
    console.log('Navigating to app...');
    // The dev server is usually on port 5173
    await page.goto('http://localhost:5173', { waitUntil: 'networkidle0' });
    
    // Check if we are on login page
    const currentUrl = page.url();
    if (currentUrl.includes('/login')) {
      console.log('On login page. Logging in...');
      await page.type('input[type="text"]', 'test@test.com'); // assuming any login works if mock is on, wait, backend has sqlite db.
      await page.type('input[type="password"]', 'password');
      await page.click('button[type="submit"]');
      await page.waitForNavigation({ waitUntil: 'networkidle0' });
    }

    console.log('Navigating to Live Dashboard...');
    // Click the Live Dashboard link (or navigate directly)
    // Actually the URL for live dashboard is /dashboard/:plantId
    await page.goto('http://localhost:5173/dashboard/jetl_hyderabad', { waitUntil: 'networkidle0' });
    
    // Wait for the Performance Gauges heading
    await page.waitForSelector('h2', { timeout: 5000 });
    
    const domCheck = await page.evaluate(() => {
      const headings = Array.from(document.querySelectorAll('h2'));
      const perfHeading = headings.find(h => h.textContent.includes('Performance Gauges'));
      
      if (!perfHeading) return { error: 'Heading not found' };
      
      let nextNode = perfHeading.nextElementSibling;
      // Skip the warning div if present
      if (nextNode && nextNode.textContent.includes('Gauges showing N/A')) {
        nextNode = nextNode.nextElementSibling;
      }
      
      if (!nextNode) return { error: 'Grid div not found' };
      
      const children = Array.from(nextNode.children).map(child => ({
        tagName: child.tagName,
        className: child.className,
        width: child.getBoundingClientRect().width,
        height: child.getBoundingClientRect().height,
        innerHTML: child.innerHTML.substring(0, 50) + '...'
      }));
      
      return {
        gridClassName: nextNode.className,
        childrenCount: children.length,
        children: children
      };
    });
    
    console.log(JSON.stringify(domCheck, null, 2));
  } catch (error) {
    console.error('Error:', error);
  } finally {
    await browser.close();
  }
})();
