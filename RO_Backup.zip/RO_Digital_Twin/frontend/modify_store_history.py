import re

with open("c:/Users/hp/OneDrive/Desktop/RO_Digital_Twin/frontend/src/store/useAppStore.js", "r", encoding="utf-8") as f:
    content = f.read()

# 1. Add telemetryHistory to initial state
state_insertion = """  // Derived KPIs (Global)
  derivedKPIs: {
    activeSEC: 2.45,
    saltRejection: 99.2,
    carbonFootprint: 1.8,
    rulDays: 850,
    healthScore: 98,
    breachTimer: 0,
    anomalyFlags: []
  },
  telemetryHistory: [],
"""
content = content.replace("  // Derived KPIs (Global)\n  derivedKPIs: {\n    activeSEC: 2.45,\n    saltRejection: 99.2,\n    carbonFootprint: 1.8,\n    rulDays: 850,\n    healthScore: 98,\n    breachTimer: 0,\n    anomalyFlags: []\n  },\n", state_insertion)

# 2. Add telemetryHistory to return of setTelemetry
return_start = content.find("    return { \n      telemetry: { ...mergedData, normalized_flux: parseFloat(trueFlux?.toFixed(1) || 0) },")
return_end = content.find("    };\n  }),", return_start)

# We want to maintain up to 288 records (24 hours at 5min intervals)
new_return = """    const newTelemetry = { ...mergedData, normalized_flux: parseFloat(trueFlux?.toFixed(1) || 0) };
    const newHistory = [...state.telemetryHistory, newTelemetry].slice(-288);
    
    return { 
      telemetry: newTelemetry,
      telemetryHistory: newHistory,
      derivedKPIs,
      sensorFaults: newFaults,
      ...( (alarmTriggered || faultAlarms.length > 0) ? { alarms: [...faultAlarms, ...newAlarms] } : {})
    };
  }),"""

content = content[:return_start] + new_return + content[return_end + 13:]

with open("c:/Users/hp/OneDrive/Desktop/RO_Digital_Twin/frontend/src/store/useAppStore.js", "w", encoding="utf-8") as f:
    f.write(content)

print("useAppStore.js history modified successfully!")
