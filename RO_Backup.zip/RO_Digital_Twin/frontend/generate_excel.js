import ExcelJS from 'exceljs';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const plants = [
  {
    id: 'jetl_hyderabad',
    params: {
      pressureBase: 40, flowBase: 38, tdsBase: 450, phBase: 7.0, tempBase: 24, turbBase: 0.3, energyBase: 90
    }
  },
  {
    id: 'waaree_chikhli',
    params: {
      pressureBase: 32, flowBase: 50, tdsBase: 200, phBase: 6.8, tempBase: 28, turbBase: 0.1, energyBase: 120
    }
  },
  {
    id: 'nia_nandesari',
    params: {
      pressureBase: 45, flowBase: 25, tdsBase: 1800, phBase: 7.5, tempBase: 26, turbBase: 1.5, energyBase: 75
    }
  }
];

async function generateExcel() {
  const outputDir = path.resolve(__dirname, '../data/processed');
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  for (const plant of plants) {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet(plant.id);

    sheet.columns = [
      { header: 'RO_Feed_Pressure_bar', key: 'RO_Feed_Pressure_bar', width: 20 },
      { header: 'Influent_Flow_m3h', key: 'Influent_Flow_m3h', width: 20 },
      { header: 'RO_Permeate_Flow_m3h', key: 'RO_Permeate_Flow_m3h', width: 20 },
      { header: 'TDS_mgL', key: 'TDS_mgL', width: 15 },
      { header: 'pH', key: 'pH', width: 10 },
      { header: 'Temperature_C', key: 'Temperature_C', width: 15 },
      { header: 'Turbidity_NTU', key: 'Turbidity_NTU', width: 15 },
      { header: 'Energy_kWh', key: 'Energy_kWh', width: 15 }
    ];

    for (let i = 0; i < 288; i++) { // 24 hours of 5-min data
      const p = plant.params;
      sheet.addRow({
        RO_Feed_Pressure_bar: p.pressureBase + (Math.random() * 5),
        Influent_Flow_m3h: p.flowBase + (Math.random() * 4),
        RO_Permeate_Flow_m3h: p.flowBase * 0.65 + (Math.random() * 3),
        TDS_mgL: p.tdsBase + (Math.random() * 100),
        pH: p.phBase + (Math.random() * 0.4),
        Temperature_C: p.tempBase + (Math.random() * 2),
        Turbidity_NTU: p.turbBase + (Math.random() * 0.4),
        Energy_kWh: p.energyBase + (Math.random() * 20)
      });
    }

    const outputPath = path.join(outputDir, `ETP_Digital_Twin_5min_Data_${plant.id}.xlsx`);
    await workbook.xlsx.writeFile(outputPath);
    console.log(`Fake Excel data generated for ${plant.id} at:`, outputPath);
  }
}

generateExcel().catch(console.error);
