import re

with open("c:/Users/hp/OneDrive/Desktop/RO_Digital_Twin/frontend/src/store/useAppStore.js", "r", encoding="utf-8") as f:
    content = f.read()

# 1. Add derivedKPIs to initial state
state_insertion = """  // Derived KPIs (Global)
  derivedKPIs: {
    activeSEC: 2.45,
    saltRejection: 99.2,
    carbonFootprint: 1.8,
    rulDays: 850,
    healthScore: 98,
    breachTimer: 0,
    anomalyFlags: []
  },
  
"""
content = content.replace("  // Telemetry & Sync State", state_insertion + "  // Telemetry & Sync State")

# 2. Modify setTelemetry to compute KPIs
set_telemetry_start = content.find("    const trueFlux = mergedData.flow_rate ? ((mergedData.flow_rate * 1000) / totalArea) : mergedData.normalized_flux;")
set_telemetry_end = content.find("    // --- Sensor Flat-line / Fault Detection ---")

kpi_computation = """
    const trueFlux = mergedData.flow_rate ? ((mergedData.flow_rate * 1000) / totalArea) : mergedData.normalized_flux;

    // --- Global Derived KPI Computation ---
    const activeSEC = mergedData.energy_kwh && mergedData.flow_rate ? (mergedData.energy_kwh / mergedData.flow_rate) : 2.5;
    const saltRejection = mergedData.conductivity && mergedData.permeate_conductivity 
      ? ((mergedData.conductivity - mergedData.permeate_conductivity) / mergedData.conductivity) * 100 
      : 98.5;
    const carbonFootprint = activeSEC * 0.82; // kg CO2 per m3
    const healthScore = Math.max(0, Math.min(100, 100 - (mergedData.differential_pressure * 2))); 
    const rulDays = Math.max(0, Math.floor(healthScore * 8.5)); // Approx days
    
    const anomalyFlags = [];
    if (activeSEC > 3.0) anomalyFlags.push('High Energy');
    if (saltRejection < 98.0) anomalyFlags.push('Poor Rejection');
    if (mergedData.differential_pressure > state.alarmLimits.deltaPWarningMargin) anomalyFlags.push('High TMP');

    const derivedKPIs = {
      activeSEC,
      saltRejection,
      carbonFootprint,
      rulDays,
      healthScore,
      breachTimer: state.derivedKPIs.breachTimer, // Preserved or incremented elsewhere
      anomalyFlags
    };

"""

content = content[:set_telemetry_start] + kpi_computation + content[set_telemetry_end:]

# 3. Modify return of setTelemetry
return_start = content.find("    return { \n      telemetry: { ...mergedData, normalized_flux: parseFloat(trueFlux?.toFixed(1) || 0) },")
return_end = content.find("    };\n  }),", return_start)

new_return = """    return { 
      telemetry: { ...mergedData, normalized_flux: parseFloat(trueFlux?.toFixed(1) || 0) },
      derivedKPIs,
      sensorFaults: newFaults,
      ...( (alarmTriggered || faultAlarms.length > 0) ? { alarms: [...faultAlarms, ...newAlarms] } : {})
    };
  }),"""

content = content[:return_start] + new_return + content[return_end + 13:]

with open("c:/Users/hp/OneDrive/Desktop/RO_Digital_Twin/frontend/src/store/useAppStore.js", "w", encoding="utf-8") as f:
    f.write(content)

print("useAppStore.js modified successfully!")
