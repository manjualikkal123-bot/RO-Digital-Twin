@echo off
echo =======================================================
echo     Starting RO Digital Twin Dashboard Services...
echo =======================================================
echo.

echo [1/3] Starting Node.js Backend Server...
start "RO Digital Twin - Backend Server" cmd /k "cd /d c:\Users\hp\OneDrive\Desktop\RO_Digital_Twin && node server.js"

echo [2/3] Starting Python ML Engine...
start "RO Digital Twin - ML Engine" cmd /k "cd /d c:\Users\hp\OneDrive\Desktop\RO_Digital_Twin && powershell -NoExit -Command ".\venv\Scripts\Activate.ps1; python ml_server.py""

echo [3/3] Starting React Frontend...
start "RO Digital Twin - Frontend UI" cmd /k "cd /d c:\Users\hp\OneDrive\Desktop\RO_Digital_Twin\frontend && npm run dev"

echo.
echo All services are spinning up! 
echo The frontend will be available at: http://localhost:5173
echo (Keep the three new command windows open to keep the servers running)
echo.
pause
