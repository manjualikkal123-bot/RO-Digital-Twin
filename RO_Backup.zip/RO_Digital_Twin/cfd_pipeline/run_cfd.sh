#!/bin/bash
# Wrapper script to run OpenFOAM synthetic data generation for the LSTM training.
# This script iterates through various spacer geometries and cross-flow velocities.

set -e

echo "Starting OpenFOAM ROM generation pipeline..."

ANGLES=( 30 45 60 )
VELOCITIES=( 0.1 0.2 0.3 )

for angle in "${ANGLES[@]}"; do
    for vel in "${VELOCITIES[@]}"; do
        echo "========================================="
        echo "Simulating Angle: $angle degrees | Velocity: $vel m/s"
        echo "========================================="
        
        # 1. Generate Mesh Dictionary
        python3 generate_mesh.py --angle "$angle" --spacing 2.0 --diameter 0.4 --out "case_${angle}_${vel}/system"
        
        # 2. Run OpenFOAM mesh generation
        # blockMesh -case "case_${angle}_${vel}"
        # snappyHexMesh -overwrite -case "case_${angle}_${vel}"
        
        # 3. Set Boundary Conditions (Velocity)
        # sed -i "s/INLET_VELOCITY/$vel/g" "case_${angle}_${vel}/0/U"
        
        # 4. Run Solver (e.g. icoFoam or custom RO solver)
        # roFoam -case "case_${angle}_${vel}"
        
        # 5. Extract Wall Shear Stress and Concentration Polarization factor
        # postProcess -func wallShearStress -case "case_${angle}_${vel}"
        
        echo "Simulation for $angle deg, $vel m/s completed (Stubbed)."
    done
done

echo "All OpenFOAM ROM simulations completed. Synthetic data ready for LSTM."
